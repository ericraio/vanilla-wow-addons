IMBA_Tracker_Enabled=false;
IMBA_Tracker_UpdateTime=0;
IMBA_Tracker_StopTimeGuild=0;
IMBA_Tracker_StopTimeRaid=0;

IMBA_Tracker_LastPos={x=0;y=0};
IMBA_Tracker_PingDelta={x=0;y=0};

IMBA_TRACKER_UPDATE_RATE = 0.5

local minimapPlayerModel;

IMBA_Minimap_Zoom={};
IMBA_Minimap_Zoom[0]={}
IMBA_Minimap_Zoom[1]={}
--For Outside of WMO's
IMBA_Minimap_Zoom[0][0]=1;
IMBA_Minimap_Zoom[0][1]=6/7;
IMBA_Minimap_Zoom[0][2]=5/7;
IMBA_Minimap_Zoom[0][3]=4/7;
IMBA_Minimap_Zoom[0][4]=3/7;
IMBA_Minimap_Zoom[0][5]=2/7;

--For Inside of WMO's
IMBA_Minimap_Zoom[1][0]=1*0.643;
IMBA_Minimap_Zoom[1][1]=4/5*0.643;
IMBA_Minimap_Zoom[1][2]=3/5*0.643;
IMBA_Minimap_Zoom[1][3]=2/5*0.643;
IMBA_Minimap_Zoom[1][4]=4/15*0.643;
IMBA_Minimap_Zoom[1][5]=1/6*0.643;


function IMBA_Tracker_OnLoad()
	DEFAULT_CHAT_FRAME:AddMessage("Tracker Loaded");
	this:RegisterEvent("MINIMAP_PING");
	this:RegisterEvent("CHAT_MSG_ADDON");
	this:RegisterEvent("RAID_ROSTER_UPDATE");

	-- Create a table of all the Minimap's children objectSimpleCompass_Saved.
	local children = {Minimap:GetChildren()};
	
	for i=getn(children), 1, -1 do
		-- Iterate over them all, starting from the end of the list to see if the object reference is a model.
		-- If it is, and it has no name (in case some addon attached a model to it), it's probably the right one.
		if children[i]:IsObjectType("Model") and not children[i]:GetName() and not minimapPlayerModel then
			-- Found, setting as the addon's local to keep the reference.
			minimapPlayerModel = children[i];
			return;
		end
	end
end


function IMBA_Tracker_OnEvent(event)
	if event=="MINIMAP_PING" then
		local x,y=Minimap:GetPingPosition();
		local zoom = IMBA_Minimap_Zoom[IMBA_isMinimapInsideWMO()][Minimap:GetZoom()];
		IMBA_Tracker_PingDelta.x=IMBA_Tracker_PingDelta.x+IMBA_Tracker_LastPos.x-x*zoom;
		IMBA_Tracker_PingDelta.y=IMBA_Tracker_PingDelta.y+IMBA_Tracker_LastPos.y-y*zoom;

		IMBA_Tracker_LastPos.x=x;
		IMBA_Tracker_LastPos.y=y;
	elseif event=="CHAT_MSG_ADDON" then
		if arg1=="IMBA_TRACKER_UPDATE" then
			if arg2=="TRANSMIT" then				
				if arg3=="RAID" then
					IMBA_Tracker_EnabledRaid=true;
					IMBA_Tracker_StopTimeRaid=GetTime()+15;
				elseif arg3=="GUILD" then
					IMBA_Tracker_EnabledGuild=true;
					IMBA_Tracker_StopTimeGuild=GetTime()+15;
				end
			end
		end
	elseif event=="RAID_ROSTER_UPDATE" then
		if IMBA_Tracker_EnabledRaid and GetNumRaidMembers()==0 then
			IMBA_Tracker_EnabledRaid=false;
		end
	end
end

function IMBA_Tracker_GetPostion()
	local x,y = Minimap:GetPingPosition();
	local zoom = IMBA_Minimap_Zoom[IMBA_isMinimapInsideWMO()][Minimap:GetZoom()];

	x=x*zoom+IMBA_Tracker_PingDelta.x;
	y=y*zoom+IMBA_Tracker_PingDelta.y;
	return x, y
end

function IMBA_Tracker_OnUpdate()
	local x,y = Minimap:GetPingPosition();
	local zoom = IMBA_Minimap_Zoom[IMBA_isMinimapInsideWMO()][Minimap:GetZoom()];

	IMBA_Tracker_LastPos.x=x*zoom
	IMBA_Tracker_LastPos.y=y*zoom

	if (IMBA_Tracker_EnabledRaid or IMBA_Tracker_EnabledGuild)  and IMBA_Tracker_UpdateTime<GetTime() then
		local ang=minimapPlayerModel:GetFacing(); 

		x=x*zoom+IMBA_Tracker_PingDelta.x;
		y=y*zoom+IMBA_Tracker_PingDelta.y;

		local _, effectiveArmor, _, _, _ = UnitArmor("player");
		local  baseDefense, armorDefense = UnitDefense("player");
		local defense=baseDefense+armorDefense
		local _, englishClass = UnitClass("player");

		local msg=string.format("%.3f %.3f %.3f %d %d %d %d %d %s %d %d",x,y,ang,UnitHealth("player"),UnitHealthMax("player"),UnitMana("player"),UnitManaMax("player"),UnitPowerType("player"),englishClass,effectiveArmor,defense);
		if IMBA_Tracker_EnabledGuild then
			SendAddonMessage("IMBA_TRACKER_DATA",msg,"GUILD");
		end
		if IMBA_Tracker_EnabledRaid then
			SendAddonMessage("IMBA_TRACKER_DATA",msg,"RAID");
		end
		DEFAULT_CHAT_FRAME:AddMessage("Tracker: "..msg,1.0,1.0,0.0);
		
		IMBA_Tracker_UpdateTime=GetTime()+IMBA_TRACKER_UPDATE_RATE;

		if IMBA_Tracker_EnabledGuild and IMBA_Tracker_StopTimeGuild<GetTime() then
			--IMBA_Tracker_EnabledGuild=false;
		end

		if IMBA_Tracker_EnabledRaid and IMBA_Tracker_StopTimeRaid<GetTime() then
			IMBA_Tracker_EnabledRaid=false;
		end
	end
end